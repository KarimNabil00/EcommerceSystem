public class Customer {
    int customerid;
     String name;
    String address;

    public int getCustomerid() {
        return customerid;
    }

    public void setCustomerid(int customerid) {
        this.customerid = Math.abs(customerid);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Customer(int customerid, String name, String address) {
        this.customerid = Math.abs(customerid);
        this.name = name;
        this.address = address;
    }
}

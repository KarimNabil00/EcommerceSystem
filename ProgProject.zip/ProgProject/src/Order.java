import javax.swing.*;

public class Order {
    int customerid;
    int orderid;
    Product[] products;
    float totalprice;

    public int getCustomerid() {
        return customerid;
    }

    public void setCustomerid(int customerid) {
        this.customerid = Math.abs(customerid);
    }

    public int getOrderid() {
        return orderid;
    }

    public void setOrderid(int orderid) {
        this.orderid = Math.abs(orderid);
    }

    public Product[] getProducts() {
        return products;
    }

    public void setProducts(Product[] products) {
        this.products = products;
    }

    public float getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(float totalprice) {
        this.totalprice = Math.abs(totalprice);
    }
    public Order(int customerid ,float totalprice, int orderid , Product[] products){
        this.customerid=Math.abs(customerid);
        this.orderid=Math.abs(orderid);
        this.products=products;
        this.totalprice=totalprice;
    }
//    public void printinfo(){
//        System.out.println("Customer ID: "+customerid);
//        System.out.println("Order ID: "+orderid);
//        for (Product p :products){
//            System.out.println(p.getName()+":"+p.getPrice()+"$");
//        }
//        System.out.println("Total Price : "+totalprice+"$");
//    }

    //GUI
    public void printinfo(){
        String list="";
        for(int i=0;i<products.length && products[i]!=null;i++){
            list+=products[i].getName()+":"+products[i].getPrice()+"$"+"\n";
        }
        JOptionPane.showMessageDialog(null,"Thank you for visiting us"+"\n"+"Your order details"+"\n"+"Customr ID: "+customerid+"\n"+"Order ID: "+orderid+"\n"+list+"Total Price: "+totalprice+"$","Ecommerce System",JOptionPane.PLAIN_MESSAGE);

    }
}

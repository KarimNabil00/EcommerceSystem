import javax.swing.*;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
//        System.out.println("Welcome");
        ElectronicProduct e1= new ElectronicProduct(1,"Smartphone",599.9f,"Samsung",1);
        ClothingProduct c1=new ClothingProduct(2,"T-shirt",19.99f,"Meduim","Cotton");
        BookProduct b1= new BookProduct(3,"OOP",39.99f,"O'Reilly","X Publications");
//        System.out.println("Enter your id");
//        int id=input.nextInt();
//        System.out.println("Enter your Name");
//        String name= input.next();
//        System.out.println("Enter your address");
//        String add=input.next();
//        Customer customer1= new Customer(id,name,add);
//        System.out.println("How many products you want to order");
//        int n=input.nextInt();
//        Cart cart = new Cart(id,n);
//        while (cart.num!=n){
//            System.out.println("1.Smartphone");
//            System.out.println("2.T-shirt");
//            System.out.println("3.OOP");
//            System.out.println("Choose the product you want from the above products");
//            int z= input.nextInt();
//            switch (z){
//                case 1:
//                    cart.addProduct(e1);
//                    break;
//                case 2:
//                    cart.addProduct(c1);
//                    break;
//                case 3:
//                    cart.addProduct(b1);
//                    break;
//                default:
//                    System.out.println("You choosed a wrong number");
//            }
//
//        }
//        System.out.println("If you want to place the order Press 1 else Press 0");
//        int placingorder= input.nextInt();
//        switch (placingorder){
//            case 1:
//                Order order1 = new Order(id,cart.CalculatePrice(),1, cart.getProducts());
//                System.out.println("Thank you for visiting us");
//                System.out.println("Here is your order Detalis");
//                order1.printinfo();
//                break;
//            case 0:
//                System.out.println("Thank you for visiting us");
//                break;
//        }





        //GUI!



        int custid2=Integer.parseInt(JOptionPane.showInputDialog(null,"Enter your ID","Ecommerce System",3));
        String name2=JOptionPane.showInputDialog(null,"Enter your Name","Ecommerce System",3);
        String add2 = JOptionPane.showInputDialog(null,"Enter your Address","Ecommerce System",3);
        Customer customer2= new Customer(custid2,name2,add2);
        int num2=Integer.parseInt(JOptionPane.showInputDialog(null,"How many Products you want to order","Ecommerce System",3));
        Cart cart2= new Cart(custid2,num2);
        String[] names = {e1.getName(),b1.getName(),c1.getName()};
        for (int i=0;i<num2;i++) {
            int z2 = JOptionPane.showOptionDialog(null, "Choose the product you want", "Ecommerce System", JOptionPane.YES_NO_CANCEL_OPTION, 3,null, names, null);
            switch (z2) {
                case 0:
                    cart2.addProduct(e1);
                    break;
                case 1:
                    cart2.addProduct(c1);
                    break;
                case 2:
                    cart2.addProduct(b1);
                    break;

            }
        }
        int placing2=JOptionPane.showOptionDialog(null, "Would you like to place an order", "Ecommerce System", JOptionPane.YES_NO_OPTION, 3,null, null, null);
        switch (placing2){
            case 0:
                Order order2= new Order(custid2,cart2.CalculatePrice(),1, cart2.getProducts());
                order2.printinfo();
                break;
            case 1:
                JOptionPane.showMessageDialog(null,"Thank you for visiting us","Ecommerce System",JOptionPane.PLAIN_MESSAGE);
                break;
        }

    }
}
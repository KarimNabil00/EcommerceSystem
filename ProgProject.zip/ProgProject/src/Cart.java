import java.time.Period;

public class Cart {
    int custemorid;
    int nProducts;
    Product[] Products;

    public int getCustemorid() {
        return custemorid;
    }

    public void setCustemorid(int custemorid) {
        this.custemorid = Math.abs(custemorid);
    }

    public int getnProducts() {
        return nProducts;
    }

    public void setnProducts(int nProducts) {
        this.nProducts = Math.abs(nProducts);
    }

    public Product[] getProducts() {
        return Products;
    }

    public void setProducts(Product[] products) {
        Products = products;
    }

    public Cart(int custemorid, int nProducts) {
        this.custemorid = Math.abs(custemorid);
        this.nProducts = Math.abs(nProducts);
        Products = new Product[nProducts];
    }
       int num=0;

    public void addProduct(Product p){
        Products[num]=p;
        num++;


    }
    public void removeProduct(Product p){
        for(int i=0;i<Products.length;i++){
            if(Products[i]==p){
                Products[i]=null;
            }
        }
    }
    float totalprice=0.0f;
    public float CalculatePrice(){
        for (Product p: Products){
            totalprice+=p.getPrice();
        }
        return totalprice;
    }
    public void Placeorder(){
        Order o1= new Order(custemorid,totalprice,1,Products);
    }

}

public class Product {
    int productid;
    String name;
    float price;

    public int getProductid() {
        return productid;
    }

    public void setProductid(int productid) {
        this.productid = Math.abs(productid);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = Math.abs(price);
    }

    public Product(int productid, String name, float price) {
        this.productid = Math.abs(productid);
        this.name = name;
        this.price = Math.abs(price);
    }
}
class ElectronicProduct extends Product{
    String brand;
    int warrantyperiod;

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getWarrantyperiod() {
        return warrantyperiod;
    }

    public void setWarrantyperiod(int warrantyperiod) {
        this.warrantyperiod = Math.abs(warrantyperiod);
    }

    public ElectronicProduct(int productid, String name, float price, String brand, int warrantyperiod) {
        super(productid, name, price);
        this.brand = brand;
        this.warrantyperiod = Math.abs(warrantyperiod);
    }
}
class ClothingProduct extends Product{
    String size;
    String fabric;

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getFabric() {
        return fabric;
    }

    public void setFabric(String fabric) {
        this.fabric = fabric;
    }

    public ClothingProduct(int productid, String name, float price, String size, String fabric) {
        super(productid, name, price);
        this.size = size;
        this.fabric = fabric;
    }
}
class BookProduct extends Product{
    String author;
    String publisher;

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public BookProduct(int productid, String name, float price, String author, String publisher) {
        super(productid, name, price);
        this.author = author;
        this.publisher = publisher;
    }
}